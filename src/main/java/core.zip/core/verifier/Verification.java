package core.verifier;

public class Verification {
}
