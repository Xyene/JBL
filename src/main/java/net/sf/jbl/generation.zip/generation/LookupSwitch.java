package net.sf.jbl.generation;

import net.sf.jbl.util.ByteStream;

import static net.sf.jbl.introspection.Opcode.LOOKUPSWITCH;

public class LookupSwitch extends Switch {

    public LookupSwitch(int addr, ByteStream stream) {
        super(addr, stream);
        opcode = LOOKUPSWITCH;

        length = stream.readInt();
        trueLen = (12 + (length << 3) + padding);

        for (int i = 0; i < length; i++) {
            addCase(stream.readInt(), stream.readInt());
        }
    }

    public LookupSwitch() {}

    public void getArguments(ByteStream out) {
        super.getArguments(out);
        int size = cases.size();
        for (int i = 0; i != size; i++) {
            Case c = cases.get(i);
            out.writeInt(c.match).writeInt(c.target);
        }
    }
}